// Review-only regression probes. This file is outside D:/repos/rawhplayer.
import React from 'react';
import { act, cleanup, render, renderHook, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { LibraryProvider, useLibrary } from '../context/LibraryContext';
import { PlayerProvider, usePlayer } from '../context/PlayerContext';
import { SettingsPage } from '../pages/SettingsPage';

const tracks = [
  { id: 'a', name: 'Track A', artist: 'Artist', path: 'C:/Music/a.wav' },
  { id: 'b', name: 'Track B', artist: 'Artist', path: 'C:/Music/b.wav' },
];
const libraryWrapper = ({ children }: { children: React.ReactNode }) => <LibraryProvider>{children}</LibraryProvider>;
const playerWrapper = ({ children }: { children: React.ReactNode }) => <PlayerProvider>{children}</PlayerProvider>;

beforeEach(() => {
  localStorage.clear();
  vi.clearAllMocks();
  vi.mocked(invoke).mockResolvedValue(undefined);
});
afterEach(() => { cleanup(); vi.unstubAllGlobals(); vi.restoreAllMocks(); });

describe('Audit: required launch behavior', () => {
  it('imports a standard File into a track with a usable native path', async () => {
    class MetadataAudio {
      duration = 1;
      onloadedmetadata?: () => void;
      onerror?: () => void;
      constructor(_url: string) { queueMicrotask(() => this.onloadedmetadata?.()); }
    }
    vi.stubGlobal('Audio', MetadataAudio);
    const { result } = renderHook(() => useLibrary(), { wrapper: libraryWrapper });
    await act(async () => { await result.current.processFiles([new File(['audio'], 'track.wav', { type: 'audio/wav' })]); });
    expect(result.current.state.tracks).toHaveLength(1);
    expect(result.current.currentTrack?.path, 'Native playback requires a filesystem path; browser File has none').toBeTruthy();
  });

  it('updates native playback when removal changes the track at the same index', async () => {
    localStorage.setItem('rawh_tracks', JSON.stringify(tracks));
    localStorage.setItem('rawh_current_track_idx', '0');
    const { result } = renderHook(() => useLibrary(), { wrapper: libraryWrapper });
    vi.mocked(invoke).mockClear();
    await act(async () => { result.current.dispatch({ type: 'REMOVE_TRACK', payload: 'a' }); });
    expect(result.current.currentTrack?.id).toBe('b');
    expect(invoke).toHaveBeenCalledWith('play_file', { path: tracks[1].path });
  });

  it('sends playback speed changes to the audio engine', async () => {
    const { result } = renderHook(() => usePlayer(), { wrapper: playerWrapper });
    vi.mocked(invoke).mockClear();
    await act(async () => { result.current.dispatch({ type: 'SET_PLAYBACK_RATE', payload: 1.5 }); });
    expect(invoke).toHaveBeenCalledWith('set_playback_rate', { rate: 1.5 });
  });

  it('displays the actual source sample rate received from Rust', async () => {
    const { result } = renderHook(() => usePlayer(), { wrapper: playerWrapper });
    const callback = vi.mocked(listen).mock.calls.find(([event]) => event === 'playback_update')?.[1];
    expect(callback).toBeTypeOf('function');
    await act(async () => {
      callback!({ event: 'playback_update', id: 1, payload: { current_time: 0, duration: 1, is_playing: true, sample_rate: 96000, bit_depth: 24 } });
    });
    expect(result.current.state.sampleRate).toBe(96000);
  });

  it('restarts a selected track after it has already been selected', async () => {
    localStorage.setItem('rawh_tracks', JSON.stringify(tracks));
    localStorage.setItem('rawh_current_track_idx', '0');
    const { result } = renderHook(() => useLibrary(), { wrapper: libraryWrapper });
    vi.mocked(invoke).mockClear();
    await act(async () => { result.current.playTrack(0); });
    expect(invoke).toHaveBeenCalledWith('play_file', { path: tracks[0].path });
  });

  it('renders Settings with the device objects returned by Rust', async () => {
    class AuditBoundary extends React.Component<{ children: React.ReactNode }, { error: string }> {
      state = { error: '' };
      static getDerivedStateFromError(error: Error) { return { error: error.message }; }
      render() { return this.state.error ? <div data-testid="audit-error">{this.state.error}</div> : this.props.children; }
    }
    vi.spyOn(console, 'error').mockImplementation(() => {});
    vi.mocked(invoke).mockImplementation(async (command) => command === 'list_audio_devices' ? [{ name: 'USB DAC', is_default: true }] as never : undefined as never);
    await act(async () => {
      render(<AuditBoundary><SettingsPage currentThemeId="neutral" onThemeChange={() => {}} isPuristMode onTogglePurist={() => {}} /></AuditBoundary>);
    });
    expect(screen.queryByTestId('audit-error'), 'Settings must accept AudioDeviceInfo {name,is_default} objects').toBeNull();
    expect(screen.getByRole('option', { name: 'USB DAC' })).toBeInTheDocument();
  });
});
