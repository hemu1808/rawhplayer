// Review-only integration probes. Native transport is mocked with real payload shapes.
import React from 'react';
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
vi.mock('../components/Visualizer', () => ({ Visualizer: () => null }));
import App from '../App';

const tracks = [
  { id: 'a', name: 'Track A', artist: 'Artist', path: 'C:/Music/a.wav' },
  { id: 'b', name: 'Track B', artist: 'Artist', path: 'C:/Music/b.wav' },
];
beforeEach(() => {
  localStorage.clear();
  vi.clearAllMocks();
  localStorage.setItem('rawh_tracks', JSON.stringify(tracks));
  localStorage.setItem('rawh_current_track_idx', '0');
});
afterEach(() => { cleanup(); vi.restoreAllMocks(); });

describe('Audit: integrated playback journeys', () => {
  it('advances to the next song when the native sink finishes', async () => {
    render(<App />);
    const emit = (name: string, payload: unknown) => {
      for (const [event, callback] of vi.mocked(listen).mock.calls) {
        if (event === name) callback({ event: name, id: 1, payload });
      }
    };
    await act(async () => { emit('playback_update', { current_time: 0.9, duration: 1, is_playing: true, sample_rate: 44100, bit_depth: 16 }); });
    vi.mocked(invoke).mockClear();
    await act(async () => {
      emit('track_ended', null);
      emit('playback_update', { current_time: 1, duration: 1, is_playing: false, sample_rate: 44100, bit_depth: 16 });
    });
    expect(invoke).toHaveBeenCalledWith('play_file', { path: tracks[1].path });
  });

  it('plays the local search result without duplicating it', async () => {
    render(<App />);
    fireEvent.click(screen.getByRole('button', { name: 'Go to Search page' }));
    const input = await screen.findByRole('textbox', { name: 'Search library' });
    fireEvent.change(input, { target: { value: 'Track B' } });
    vi.mocked(invoke).mockClear();
    fireEvent.click(screen.getByRole('button', { name: 'Play search result: Track B by Artist' }));
    expect.soft(JSON.parse(localStorage.getItem('rawh_tracks')!)).toHaveLength(2);
    expect(invoke).toHaveBeenCalledWith('play_file', { path: tracks[1].path });
  });
});
