**Rawh Player implementation backlog - 21 October 2026.**

Companion to [the detailed implementation plan](C:/Users/hemu1/rawhplayer-audit-20261021/IMPLEMENTATION_PLAN_2026-10-21.md). This is proposed work; no implementation is represented as completed. Estimates are aggregate engineer-days and include ordinary testing/review. Re-estimate after the native audio experiment. Signing-provider lead times, a direct CPAL fallback, research projects and 20-30% recommended schedule contingency are excluded.

Read dependencies as merge/integration prerequisites. Test design, signing setup and documentation preparation can start before those prerequisites merge. Each item is a work package; split a package into smaller pull requests when necessary. A release must satisfy its milestone gate in the main plan.

| Milestone | Packages | Base effort |
|---|---:|---:|
| beta | 17 | 27-49 engineer-days |
| stable | 8 | 13-27 engineer-days |
| advanced | 8 | 21-38 engineer-days |
| platform | 2 | 10-20 engineer-days |

| ID | Deliverable | Owner role | Effort | Depends on |
|---|---|---|---|---|
| B01 | Preserve and document the intended baseline | Lead | 1-2 d | None |
| B02 | Repair JavaScript dependency and quality tooling | Frontend | 1-2 d | B01 |
| B03 | Establish the Windows native toolchain and build | Native | 1-3 d | B01, B02 |
| B04 | Prove the audio backend and freeze its contract | Native | 2-3 d | B03 |
| B05 | Define typed IPC and playback snapshots | Native + Frontend | 1-2 d | B03 |
| B06 | Introduce the durable library database | Native | 2-3 d | B05 |
| B07 | Replace browser import with native media ingestion | Native + Frontend | 2-3 d | B05, B06 |
| B08 | Make the native controller own playback | Native + Frontend | 3-5 d | B04, B05 |
| B09 | Fix seeking, sample precision and DSP reporting | Native | 2-4 d | B08 |
| B10 | Separate queue identity and implement transition rules | Native + Frontend | 2-3 d | B06, B07, B08 |
| B11 | Implement real output selection and recovery | Native + Frontend | 1-2 d | B08, B09 |
| B12 | Migrate existing data and restore sessions safely | Native + Frontend | 1-3 d | B06, B07, B10 |
| B13 | Complete the launch user journeys | Frontend | 2-3 d | B07, B09, B10, B11, B12 |
| B14 | Constrain native access and finish Windows integration | Native | 1-2 d | B05, B07, B08 |
| B15 | Qualify the installed Windows beta | QA + Native | 2-4 d | B09, B10, B11, B12, B13, B14, B16 |
| B16 | Build and sign a gated Windows installer | Release | 2-3 d | B02, B03, B14 |
| B17 | Publish accurate beta documentation and evidence | Lead + QA | 1-2 d | B15, B16 |
| S01 | Verify gapless album playback | Native | 2-4 d | B17 |
| S02 | Meet performance and audio stability budgets | Native + Frontend | 2-4 d | B17, S01 |
| S03 | Complete security, privacy and support diagnostics | Native + Release | 1-3 d | B17 |
| S04 | Deliver signed updates and recovery | Release + Native | 3-5 d | B17, S03 |
| S05 | Finish accessibility and visual consistency | Frontend + QA | 1-2 d | B17 |
| S06 | Prove data recovery at library scale | Native + QA | 1-3 d | B17, S03 |
| S07 | Run production release qualification | QA + Native + Release | 2-4 d | S01, S02, S03, S04, S05, S06 |
| S08 | Prepare support and staged stable rollout | Lead + Release | 1-2 d | S07 |
| A01 | Add reliable watched folders | Native | 2-4 d | S08 |
| A02 | Ship safe metadata editing | Native + Frontend | 2-4 d | S08 |
| A03 | Add ReplayGain and measured loudness controls | Native + Frontend | 3-5 d | S08, S01, S02 |
| A04 | Build smart playlists and trustworthy listening history | Native + Frontend | 2-4 d | A01 |
| A05 | Implement actual crossfade | Native | 4-7 d | A03 |
| A06 | Ship direct internet radio as a distinct source | Native + Frontend | 3-6 d | S08, S03, S04 |
| A07 | Add a real mini player and Windows media controls | Native + Frontend | 3-5 d | S08 |
| A08 | Polish lyrics and artwork themes | Frontend + Native | 2-3 d | S03 |
| A09 | Qualify macOS after Windows stable | Native + Release + QA | 5-10 d | S08 |
| A10 | Qualify a bounded Linux support matrix | Native + Release + QA | 5-10 d | A09 |

**B01. Preserve and document the intended baseline.** beta; Lead; 1-2 engineer-days.

Changes: Inventory modified and untracked files; record a source snapshot; classify release features and known defects.

Files and proposed modules: `App.tsx`, `context/`, `tests/`, `.github/`, `codex.md`.

Acceptance: A reviewable baseline includes contexts, tests and workflows; no user work is lost.

Dependencies: None.

**B02. Repair JavaScript dependency and quality tooling.** beta; Frontend; 1-2 engineer-days.

Changes: Pin Node 24 LTS; align Vite, React plugin, Vitest and Lucide; add lint, formatter and coverage dependencies; regenerate lockfile.

Files and proposed modules: `package.json`, `package-lock.json`, `vite.config.ts`, `vitest.config.ts`, `.eslintrc.cjs`.

Acceptance: A clean npm ci passes without legacy peer flags; typecheck, lint, tests and production bundle pass.

Dependencies: B01.

**B03. Establish the Windows native toolchain and build.** beta; Native; 1-3 engineer-days.

Changes: Pin a verified Rust compiler and MSVC target; validate SDK/WebView prerequisites; reinstall Tauri CLI from lock; compile native code and inventory warnings.

Files and proposed modules: `src-tauri/Cargo.toml`, `src-tauri/Cargo.lock`, `src-tauri/tauri.conf.json`, `proposed rust-toolchain.toml`.

Acceptance: Fresh Windows build and launch succeed; exact compiler and dependency versions are recorded.

Dependencies: B01, B02.

**B04. Prove the audio backend and freeze its contract.** beta; Native; 2-3 engineer-days.

Changes: Timebox a Rodio upgrade experiment behind an adapter; test float decode precision, seek, ownership and boundaries; choose one backend.

Files and proposed modules: `src-tauri/src/audio_engine.rs`, `proposed src-tauri/src/audio/backend.rs`, `proposed native fixtures`.

Acceptance: Written decision plus WAV/FLAC 24-bit fixtures, paused seek and device lifecycle evidence; direct CPAL fallback is re-estimated if needed.

Dependencies: B03.

**B05. Define typed IPC and playback snapshots.** beta; Native + Frontend; 1-2 engineer-days.

Changes: Define Rust DTOs, generated TypeScript types, validated inputs, structured errors, session epochs, revisions and one IPC client.

Files and proposed modules: `src-tauri/src/lib.rs`, `types.ts`, `proposed src-tauri/src/commands/`, `proposed services/nativeClient.ts`.

Acceptance: Rust serialization and frontend parsing agree; invalid commands are rejected; stale events cannot replace current state.

Dependencies: B03.

**B06. Introduce the durable library database.** beta; Native; 2-3 engineer-days.

Changes: Create a Rust-owned SQLite worker, transactional migrations, tracks/files/playlists/queue/settings tables, indexes and paged search.

Files and proposed modules: `proposed src-tauri/src/storage/`, `proposed src-tauri/migrations/`, `services/statsService.ts`.

Acceptance: Transactions and restart work; failed migration preserves the previous data; queries run off the audio thread.

Dependencies: B05.

**B07. Replace browser import with native media ingestion.** beta; Native + Frontend; 2-3 engineer-days.

Changes: Use native pickers/drop paths; authorize files; scan metadata in bounded workers; deduplicate file identity; cache artwork; report cancellation and errors.

Files and proposed modules: `pages/FilesPage.tsx`, `hooks/useDragDrop.ts`, `context/LibraryContext.tsx`, `proposed src-tauri/src/library/`.

Acceptance: Picker/drop/reimport/restart journeys pass with Unicode, missing and corrupt media; no persistent blob URLs.

Dependencies: B05, B06.

**B08. Make the native controller own playback.** beta; Native + Frontend; 3-5 engineer-days.

Changes: Introduce an owning audio thread and explicit state machine; commands replace index effects; implement pause/resume/stop and event reconciliation.

Files and proposed modules: `src-tauri/src/audio_engine.rs`, `src-tauri/src/lib.rs`, `context/PlayerContext.tsx`, `context/LibraryContext.tsx`, `App.tsx`.

Acceptance: Rapid play/pause/replace and stop are deterministic; workers cancel/join; no unsupported manual Send/Sync wrapper remains.

Dependencies: B04, B05.

**B09. Fix seeking, sample precision and DSP reporting.** beta; Native; 2-4 engineer-days.

Changes: Forward/implement seeking and flush old frames; preserve supported source precision; smooth volume/EQ; validate controls; expose actual signal path.

Files and proposed modules: `src-tauri/src/audio_engine.rs`, `hooks/useEqualizer.ts`, `components/Equalizer.tsx`, `pages/AudiophilePage.tsx`.

Acceptance: 24-bit reference test, repeated and paused seeks, channel alignment and bypass tests pass; no unsupported bit-perfect claim.

Dependencies: B08.

**B10. Separate queue identity and implement transition rules.** beta; Native + Frontend; 2-3 engineer-days.

Changes: Use queue-entry IDs distinct from track IDs; implement explicit next/previous/EOF, repeat and shuffle rules; repair search play and queue removal.

Files and proposed modules: `App.tsx`, `context/LibraryContext.tsx`, `components/QueueSidebar.tsx`, `components/QueueDrawer.tsx`, `pages/SearchPage.tsx`.

Acceptance: All eight audit behaviors are resolved across the relevant packages; model tests cover duplicates, EOF and mutations.

Dependencies: B06, B07, B08.

**B11. Implement real output selection and recovery.** beta; Native + Frontend; 1-2 engineer-days.

Changes: Return typed device descriptors; switch output with acknowledged success; handle no device, unplug, sleep and failed selection.

Files and proposed modules: `pages/SettingsPage.tsx`, `context/PlayerContext.tsx`, `proposed src-tauri/src/audio/device.rs`.

Acceptance: Settings renders native payloads; selected device matches active output; unplug pauses without surprise speaker fallback.

Dependencies: B08, B09.

**B12. Migrate existing data and restore sessions safely.** beta; Native + Frontend; 1-3 engineer-days.

Changes: Validate legacy localStorage; migrate once transactionally; retain recoverable non-secret backup; rebuild artwork; restore a paused session; provide library export/restore.

Files and proposed modules: `hooks/usePersistence.ts`, `context/LibraryContext.tsx`, `services/statsService.ts`, `proposed src-tauri/src/storage/migration.rs`.

Acceptance: Interrupted and repeated migrations are safe; invalid paths request relinking; library, queue and favorites survive restart.

Dependencies: B06, B07, B10.

**B13. Complete the launch user journeys.** beta; Frontend; 2-3 engineer-days.

Changes: Wire every visible control; add loading/error/retry states; virtualize library lists; correct focus/labels/keyboard behavior; gate unfinished pages.

Files and proposed modules: `App.tsx`, `components/Controls.tsx`, `components/TrackList.tsx`, `pages/SettingsPage.tsx`, `components/Navigation.tsx`, `hooks/useKeyboardShortcuts.ts`.

Acceptance: Import to play to seek to next to restart works using mouse and keyboard; every exposed control has observable native behavior.

Dependencies: B07, B09, B10, B11, B12.

**B14. Constrain native access and finish Windows integration.** beta; Native; 1-2 engineer-days.

Changes: Grant explicit window actions; validate custom IPC file access; remove inactive write/network handlers; route file-open and single-instance launches through the importer.

Files and proposed modules: `src-tauri/build.rs`, `src-tauri/capabilities/default.json`, `src-tauri/src/lib.rs`, `src-tauri/tauri.conf.json`, `components/TitleBar.tsx`.

Acceptance: Window buttons work in the packaged app; unauthorized paths/commands fail; file associations target only verified codecs.

Dependencies: B05, B07, B08.

**B15. Qualify the installed Windows beta.** beta; QA + Native; 2-4 engineer-days.

Changes: Run Rust integration tests, adapted audit regressions, desktop WebDriver journeys, install/uninstall and an eight-hour hardware soak.

Files and proposed modules: `tests/`, `proposed tests/e2e/`, `proposed src-tauri/tests/`, `proposed docs/validation/`.

Acceptance: No release-blocking crash, wrong-track, data-loss or stuck-playback defects; results include machine/device/fixture versions.

Dependencies: B09, B10, B11, B12, B13, B14, B16.

**B16. Build and sign a gated Windows installer.** beta; Release; 2-3 engineer-days.

Changes: Start code-signing ownership early; gate packaging on frontend/native CI; produce a signed x64 NSIS installer; retain hashes and version metadata.

Files and proposed modules: `.github/workflows/ci.yml`, `.github/workflows/release.yml`, `src-tauri/tauri.conf.json`, `package.json`, `src-tauri/Cargo.toml`.

Acceptance: Clean VM installs and launches the same signed artifact produced from the passing commit; no updater placeholder is active.

Dependencies: B02, B03, B14.

**B17. Publish accurate beta documentation and evidence.** beta; Lead + QA; 1-2 engineer-days.

Changes: Document verified formats/platforms, known limitations, privacy, recovery, feedback and a capability checklist; prepare a limited beta handoff.

Files and proposed modules: `README.md`, `CHANGELOG.md`, `PRIVACY.md`, `featurewalkthrough.md`, `proposed docs/release-checklist.md`.

Acceptance: Beta gate is signed off against evidence; product claims match implemented capabilities; support can reproduce reported failures.

Dependencies: B15, B16.

**S01. Verify gapless album playback.** stable; Native; 2-4 engineer-days.

Changes: Prefetch the next decoder; consume explicit boundary markers; account for codec delay/padding; preserve a continuous output stream.

Files and proposed modules: `proposed src-tauri/src/audio/decoder.rs`, `proposed src-tauri/src/playback/queue.rs`, `proposed src-tauri/tests/gapless.rs`.

Acceptance: Captured PCM boundary tests show no added/dropped frames for declared formats/configurations; queue edits cancel stale prefetch.

Dependencies: B17.

**S02. Meet performance and audio stability budgets.** stable; Native + Frontend; 2-4 engineer-days.

Changes: Replace per-sample FFT locking with bounded frame-aligned data exchange; suspend hidden visualizers; tune query/render paths and callback work.

Files and proposed modules: `src-tauri/src/audio_engine.rs`, `components/Visualizer.tsx`, `components/TrackList.tsx`, `hooks/useDynamicTheme.ts`.

Acceptance: Reference-machine latency, CPU/memory and 100k-library budgets pass; a 24-hour soak has no unexplained gaps or unbounded growth.

Dependencies: B17, S01.

**S03. Complete security, privacy and support diagnostics.** stable; Native + Release; 1-3 engineer-days.

Changes: Finish dependency/license review, local redacted logs and diagnostic export, CSP/resource restrictions, secret migration/removal and privacy inventory.

Files and proposed modules: `src-tauri/src/lib.rs`, `src-tauri/tauri.conf.json`, `pages/SettingsPage.tsx`, `PRIVACY.md`, `proposed src-tauri/src/diagnostics/`.

Acceptance: Support bundle excludes keys and full paths by default; release-critical advisories are resolved; advertised offline mode has no unexpected requests.

Dependencies: B17.

**S04. Deliver signed updates and recovery.** stable; Release + Native; 3-5 engineer-days.

Changes: Provision updater keys separately from OS signing; generate manifests; add opt-in install/restart flow and channels; snapshot before migrations; test interruption.

Files and proposed modules: `.github/workflows/release.yml`, `src-tauri/tauri.conf.json`, `src-tauri/src/lib.rs`, `pages/SettingsPage.tsx`, `proposed src-tauri/src/updates.rs`.

Acceptance: Previous beta updates to candidate; bad signature, truncated download and migration failure preserve a runnable app and recoverable library.

Dependencies: B17, S03.

**S05. Finish accessibility and visual consistency.** stable; Frontend + QA; 1-2 engineer-days.

Changes: Test Narrator/keyboard/focus/contrast/reduced motion/high DPI; finish reusable controls and virtualized-list behavior; repair specific findings.

Files and proposed modules: `components/`, `pages/`, `hooks/useKeyboardShortcuts.ts`, `hooks/useDynamicTheme.ts`, `index.css`.

Acceptance: Core journeys work with Narrator and keyboard at tested scale factors; no unsupported accessibility certification claim.

Dependencies: B17.

**S06. Prove data recovery at library scale.** stable; Native + QA; 1-3 engineer-days.

Changes: Exercise migration fixtures, read-only/full/corrupt storage, online backups, restore validation and interrupted writes with 100k tracks.

Files and proposed modules: `proposed src-tauri/src/storage/`, `proposed src-tauri/tests/storage_recovery.rs`.

Acceptance: Pre-upgrade snapshot restores in a clean profile; acknowledged durable mutations survive the defined crash model.

Dependencies: B17, S03.

**S07. Run production release qualification.** stable; QA + Native + Release; 2-4 engineer-days.

Changes: Run the complete media/device/OS/update matrix against the exact release candidate; fix and rerun affected gates; validate notices and hashes.

Files and proposed modules: `proposed docs/validation/`, `proposed docs/release-checklist.md`, `.github/workflows/release.yml`.

Acceptance: Zero open release blockers; build, audio, install, update, recovery, privacy and accessibility evidence is attached.

Dependencies: S01, S02, S03, S04, S05, S06.

**S08. Prepare support and staged stable rollout.** stable; Lead + Release; 1-2 engineer-days.

Changes: Document release ownership, stop-rollout criteria, key recovery, incident triage and a forward-fix process; promote the qualified artifact in cohorts.

Files and proposed modules: `proposed docs/operations.md`, `CHANGELOG.md`, `proposed docs/support.md`.

Acceptance: Support has the runbook and symbols; distribution can be paused; installer and feed refer to the qualified hashes.

Dependencies: S07.

**A01. Add reliable watched folders.** advanced; Native; 2-4 engineer-days.

Changes: Persist roots; debounce/coalesce filesystem events; detect rename/delete; reconcile with full scans; cancel bounded jobs.

Files and proposed modules: `src-tauri/src/watcher.rs`, `proposed src-tauri/src/library/`.

Acceptance: Burst changes and missed events converge without duplicate tracks or playback stalls.

Dependencies: S08.

**A02. Ship safe metadata editing.** advanced; Native + Frontend; 2-4 engineer-days.

Changes: Implement field-level patches with explicit clear semantics; preserve untouched tags/art; stage and verify writes with recovery and concurrent-file checks.

Files and proposed modules: `src-tauri/src/audio_engine.rs`, `proposed src-tauri/src/library/metadata.rs`, `proposed components/MetadataEditor.tsx`.

Acceptance: Failed edit does not lose the original; external changes and playing-file locks produce a safe user decision.

Dependencies: S08.

**A03. Add ReplayGain and measured loudness controls.** advanced; Native + Frontend; 3-5 engineer-days.

Changes: Parse track/album gain and peaks; offer explicit modes, preamp and clipping prevention; batch optional analysis off the audio thread.

Files and proposed modules: `proposed src-tauri/src/audio/dsp/`, `components/Equalizer.tsx`, `pages/AudiophilePage.tsx`.

Acceptance: Reference loudness and true-peak/peak policies are documented and tested; switching modes preserves consistent album behavior.

Dependencies: S08, S01, S02.

**A04. Build smart playlists and trustworthy listening history.** advanced; Native + Frontend; 2-4 engineer-days.

Changes: Add indexed playlist rules and batched native listening sessions; distinguish played time from seeking, buffering and pause.

Files and proposed modules: `services/statsService.ts`, `pages/PlaylistPage.tsx`, `proposed src-tauri/src/storage/`.

Acceptance: Rules are deterministic; interrupted sessions avoid double counting; histories persist without per-second whole-store writes.

Dependencies: A01.

**A05. Implement actual crossfade.** advanced; Native; 4-7 engineer-days.

Changes: Mix two prepared sources using an explicit curve and headroom; handle cancellation, seek, repeat and albums; expose feature compatibility.

Files and proposed modules: `proposed src-tauri/src/audio/mixer.rs`, `pages/SettingsPage.tsx`.

Acceptance: Captured overlap follows the curve without clipping; skip/seek cancels stale sources; album-gapless mode remains intact.

Dependencies: A03.

**A06. Ship direct internet radio as a distinct source.** advanced; Native + Frontend; 3-6 engineer-days.

Changes: Implement HTTP stream routing, bounded buffering, deadlines, redirect validation, ICY metadata and reconnect; disclose network behavior.

Files and proposed modules: `pages/RadioPage.tsx`, `services/radioService.ts`, `pages/ConnectPage.tsx`, `proposed src-tauri/src/network/streams.rs`.

Acceptance: Bad URLs, wrong MIME, redirect loops, stalls and cancellation do not hang or impersonate a local track.

Dependencies: S08, S03, S04.

**A07. Add a real mini player and Windows media controls.** advanced; Native + Frontend; 3-5 engineer-days.

Changes: Create a restricted native mini window; connect SMTC/media keys and main window to the same controller; persist window state.

Files and proposed modules: `components/MiniPlayer.tsx`, `src-tauri/src/lib.rs`, `src-tauri/capabilities/`, `proposed src-tauri/src/platform/windows.rs`.

Acceptance: All controllers display the same active entry and cannot duplicate commands; focus, tray and close behavior are documented.

Dependencies: S08.

**A08. Polish lyrics and artwork themes.** advanced; Frontend + Native; 2-3 engineer-days.

Changes: Add cancellable cached lyrics with explicit plain/synchronized status; bound artwork analysis and discard stale results; enforce contrast.

Files and proposed modules: `components/LyricsPanel.tsx`, `hooks/useDynamicTheme.ts`, `PRIVACY.md`.

Acceptance: Offline and rapid-track changes show correct content; external requests match privacy choices.

Dependencies: S03.

**A09. Qualify macOS after Windows stable.** platform; Native + Release + QA; 5-10 engineer-days.

Changes: Select supported macOS/architectures; verify CoreAudio, files/devices, signing/notarization, updates, media keys and installer behavior.

Files and proposed modules: `src-tauri/src/platform/ proposed`, `src-tauri/tauri.conf.json`, `.github/workflows/release.yml`, `proposed tests/e2e/`.

Acceptance: Signed/notarized packages pass the same core, migration and audio evidence gates on actual target hardware.

Dependencies: S08.

**A10. Qualify a bounded Linux support matrix.** platform; Native + Release + QA; 5-10 engineer-days.

Changes: Choose supported distributions, audio servers and packaging; validate WebKit dependencies, sandbox paths, device access, updates and media controls.

Files and proposed modules: `src-tauri/Cargo.toml`, `src-tauri/tauri.conf.json`, `.github/workflows/release.yml`, `proposed tests/e2e/`.

Acceptance: Declared distro/package combinations pass native audio, installation, persistence and updates on real desktops.

Dependencies: A09.

