**Rawh Player: implementation and launch plan - 21 October 2026**

**Recommendation: release a dependable Windows desktop player first, with a native playback controller, durable library, accurate audio information and a verified installer. Follow with production update/recovery work, advanced audio and library features, then macOS and Linux.** Keep React, TypeScript, Tauri and Rust. Improve their boundaries incrementally.

This plan is based on the audited working tree at `D:/repos/rawhplayer`, HEAD `71a924c`, including its existing modifications and untracked files. Windows first, followed by macOS and Linux, is the user's confirmed platform decision. Windows 11 x64 is the proposed first support target; exact Windows builds, WebView2 prerequisites and device coverage must be recorded during qualification. Windows ARM and older Windows versions require separate qualification before being advertised.

These are proposed changes. No application source has been changed for this plan. Native compilation, real audio output and installation were not verified in the audit because Rust tooling was unavailable. Current dependency documentation was checked on 21 October 2026; resolve and pin compatible patch versions during implementation.

Use the [launch review](C:/Users/hemu1/rawhplayer-audit-20261021/LAUNCH_REVIEW_2026-10-21.md) for evidence, the [35-package backlog](C:/Users/hemu1/rawhplayer-audit-20261021/IMPLEMENTATION_BACKLOG.md) for assignment and acceptance criteria, and its [CSV](C:/Users/hemu1/rawhplayer-audit-20261021/IMPLEMENTATION_BACKLOG.csv) or [JSON](C:/Users/hemu1/rawhplayer-audit-20261021/IMPLEMENTATION_BACKLOG.json) for importing into a tracker.

**1. Define the product promise and release boundaries.**

The first product promise should be: import your music, find it quickly, play the intended track reliably, control playback accurately and keep your library across restarts and upgrades. The differentiators should build on that promise: a transparent signal-path display, dependable album playback, useful library tools and a polished desktop interface.

| Capability | Private Windows beta | Public Windows stable | Subsequent releases |
|---|---|---|---|
| Local files and folders | Native import/drop, metadata, artwork, deduplication and cancellation | Scale and recovery qualification | Watched folders and incremental reconciliation |
| Library | Search, favorites, named playlists, stable track identity | Large-library performance and export/restore verification | Smart playlists, richer history and relinking tools |
| Playback | Play/pause/resume/stop/seek, queue, next/previous, shuffle, repeat | Proven gapless playback for declared formats and configurations | Crossfade, additional formats and specialized output modes |
| Audio output | Real device selection, safe device-loss behavior, verified 16/24-bit source decoding | Documented source/engine/device signal path and long-duration stability | Measured exclusive output and any bit-perfect claim |
| DSP | Working EQ, volume, mute and clearly labeled DSP bypass | Measured response, headroom and stable parameter changes | ReplayGain, album loudness and optional limiter |
| Desktop UX | Working title bar, keyboard controls, file opening, restart restoration | Accessibility, high-DPI and installation/update qualification | Native mini player, richer media-session integration |
| Delivery | Signed installer for a limited test cohort; manual upgrades can be used | Signed updates, migration backups, recovery and support runbooks | macOS, then a declared Linux matrix |
| Network features | Gate unfinished radio, remote search/import and key-entry UI | Only expose a separately completed and tested connector | Direct radio first; other providers require their own supported integration |
| AI, VST, spatial and room correction | Exclude unfinished modules from release capability claims | Keep outside the launch critical path | Separate research and product milestones |

Create one release capability manifest, consumed by both native registration/build configuration and the frontend. A capability is enabled only when its command handlers, persistence, permissions, UI, error behavior and tests are complete. Frontend hiding alone does not remove an exposed native command. In release builds, fake search results and generated mock playlist contents must be absent.

Initially qualify WAV/PCM, FLAC and MP3. Add AAC/M4A, Ogg codecs, AIFF or other formats to the advertised list only after fixtures pass. The importer, file associations, documentation and capability manifest must use the same verified list. Detect the actual container and codec; an extension alone is insufficient. Reject unsupported channel layouts clearly until a tested downmix exists. Remove DSF/DFF support claims while no verified decoder is available.

Treat the existing `3.0.0` version as a starting point to inspect. Check previously distributed versions before choosing the next release number; do not reuse a published version or create an unintended downgrade. A `3.0.0-beta.N` sequence is suitable only if the actual release history permits it.

**2. Turn the audit findings into specific engineering outcomes.**

The existing frontend build and 30 tests pass with installed dependencies, but a clean dependency installation fails, lint tooling is missing, eight additional behavioral checks fail, and the native application remains unverified. Those facts define the starting baseline, not the finished quality bar.

| Current failure | Required change | Main existing files | Backlog |
|---|---|---|---|
| Browser files lack usable native paths | Native selection/drop, backend authorization and native metadata ingestion | [LibraryContext](D:/repos/rawhplayer/context/LibraryContext.tsx), [FilesPage](D:/repos/rawhplayer/pages/FilesPage.tsx), [useDragDrop](D:/repos/rawhplayer/hooks/useDragDrop.ts) | B07 |
| Index-based selection, duplicate search results, queue desynchronization | Stable track and queue-entry identities; explicit native commands | [App](D:/repos/rawhplayer/App.tsx), LibraryContext, queue components | B08, B10 |
| EOF event is not used and transitions are inferred from position changes | Native queue transitions with explicit source-boundary events | [audio_engine](D:/repos/rawhplayer/src-tauri/src/audio_engine.rs), [PlayerContext](D:/repos/rawhplayer/context/PlayerContext.tsx) | B08, B10, S01 |
| Device objects crash Settings; selection has no effect | Shared device DTO and acknowledged switch command | [SettingsPage](D:/repos/rawhplayer/pages/SettingsPage.tsx), audio_engine | B05, B11 |
| Seeking stops at the DSP wrapper | Correct decoder seek/flush/reset semantics through the chosen backend | audio_engine | B04, B09 |
| 24-bit input is reduced through the old decoder adapter | Verify a precision-preserving decode path and truthful output reporting | [Cargo.toml](D:/repos/rawhplayer/src-tauri/Cargo.toml), audio_engine, [AudiophilePage](D:/repos/rawhplayer/pages/AudiophilePage.tsx) | B04, B09 |
| Sample-rate display and several settings do not reflect native behavior | Render confirmed capabilities and signal-path state; implement or gate controls | [types](D:/repos/rawhplayer/types.ts), PlayerContext, SettingsPage, [Controls](D:/repos/rawhplayer/components/Controls.tsx) | B05, B09, B13 |
| Library/artwork/stats persistence is fragile | Rust-owned SQLite, stable artwork cache and transactional migration | [usePersistence](D:/repos/rawhplayer/hooks/usePersistence.ts), [statsService](D:/repos/rawhplayer/services/statsService.ts), LibraryContext | B06, B12 |
| Unsafe/unbounded command inputs and arbitrary file access | Validate every native request and resolve authorized library IDs | [lib.rs](D:/repos/rawhplayer/src-tauri/src/lib.rs), audio_engine, [capabilities](D:/repos/rawhplayer/src-tauri/capabilities/default.json) | B05, B14 |
| Title-bar actions and file associations are incomplete | Explicit window permissions and one file-open ingestion route | [TitleBar](D:/repos/rawhplayer/components/TitleBar.tsx), lib.rs, [Tauri configuration](D:/repos/rawhplayer/src-tauri/tauri.conf.json) | B14 |
| Installation/update pipeline is incomplete | Gate builds, sign installers and updates separately, test upgrade/recovery | [CI](D:/repos/rawhplayer/.github/workflows/ci.yml), [release workflow](D:/repos/rawhplayer/.github/workflows/release.yml), Tauri configuration | B16, S04 |

Port the eight audit regressions into the evolving suite as user-visible requirements. Their current mocks and component wiring can change when the architecture changes; the expected behaviors must remain. Do not merely make the existing mock shape match the buggy implementation.

**3. Repair the development baseline before product expansion.**

Preserve all existing work, including untracked contexts, hooks, native modules, tests and workflows. Create a reviewable baseline commit or isolated branch during implementation after inventorying it; avoid a mass reset or an immediate directory-wide rewrite. Capture the dependency/build results and the exact source revision used for every validation run.

Standardize on Node 24 LTS, with an exact approved patch and npm version recorded. Align Vite, its React plugin, Vitest, jsdom, testing-library and Lucide as a compatible set. The current Vite 5 installation is outside the support policy; evaluate the current supported Vite line and use the matching migration guides. Node's current schedule lists 24 as LTS and 20 as EOL. [Node lifecycle](https://nodejs.org/en/about/previous-releases), [Vite support policy](https://vite.dev/releases).

Add the actual dependencies required by lint, formatting and coverage scripts. Use a compatible ESLint configuration, preferably a flat configuration when selecting a current major. Keep formatting-only edits separate from behavior changes. Require a clean `npm ci` without peer-dependency bypass flags. Reinstall the Tauri CLI from the repaired lockfile and check its package integrity; do not patch its malformed installed JavaScript by hand.

Add a pinned `rust-toolchain.toml`, the MSVC target, a documented Windows SDK/build-tools setup and locked Cargo builds. Align the application's declared Rust minimum with the selected dependency graph: current Tauri dialog/updater documentation lists Rust 1.90 as its minimum, while this repository declares 1.77.2. That does not establish the minimum of the existing lockfile; verify the versions actually selected. [Tauri dialog prerequisites](https://v2.tauri.app/plugin/dialog/), [Tauri updater prerequisites](https://v2.tauri.app/plugin/updater/).

Keep React 19, strict TypeScript and the current Tauri architecture. Introduce feature boundaries as code is touched. Add `noUncheckedIndexedAccess` after correcting array assumptions, then consider `exactOptionalPropertyTypes` in a separate focused change. Do not combine a style-system migration or Rust edition migration with playback fixes unless an actual dependency requires it.

**4. Establish one authoritative playback controller.**

Rust should own the active source, playback lifecycle, queue, device, DSP settings and actual position. React should own presentation state such as an open drawer, active page and pending user intent. The UI sends commands and renders acknowledged native snapshots. A successful enqueue acknowledgement is distinct from confirmation that audio has started.

```mermaid
flowchart TD
  UI[React views and presentation state] --> IPC[Typed IPC client]
  IPC --> CMD[Rust command validation]
  CMD --> PC[Playback controller and queue]
  CMD --> LIB[Library and storage services]
  LIB --> DB[(SQLite and artwork cache)]
  PC --> DEC[Bounded decoder workers]
  DEC --> PCM[Prepared PCM frames]
  PC --> OUT[Audio owner and output backend]
  PCM --> OUT
  OUT --> DEV[Windows audio device]
  OUT --> EVENTS[Snapshots and bounded telemetry]
  PC --> EVENTS
  EVENTS --> UI
```

Keep the audio stream's creation, control and destruction within the thread/lifetime model required by the selected backend. Remove the current manual `unsafe impl Send/Sync` wrapper when the owner-based implementation lands. Sending control messages between threads should not require moving a platform audio object unsafely. Retain worker handles, cancel obsolete work and join workers on shutdown.

Split responsibilities incrementally. Proposed Rust modules are `commands/`, `playback/controller.rs`, `playback/queue.rs`, `audio/backend.rs`, `audio/decoder.rs`, `audio/device.rs`, `audio/dsp/`, `library/`, `storage/`, `diagnostics/` and `updates.rs`. Keep `lib.rs` focused on registration and application setup. Move the existing implementation in small tested steps; do not leave two live playback controllers.

Proposed frontend boundaries are `services/nativeClient.ts`, generated IPC types, playback/library selectors and feature-specific view models. Existing contexts can become thin adapters first. Subscribe through a small external store with selectors, or equivalent fine-grained subscriptions, so progress events do not rerender every library row. A global state-library replacement is optional; correct ownership is mandatory.

Every playback snapshot should include a schema version, application-session ID, monotonically increasing revision, playback generation, active queue-entry ID, state, position, duration, volume/mute, repeat/shuffle and source/engine/output information. Source replacement or seek invalidates outstanding decoder work through a generation token. Events from a previous session or generation cannot overwrite the current session.

Subscribe before obtaining the initial snapshot, buffer intervening events and reconcile by revision. An event gap should trigger a fresh snapshot. The main window and future mini player must follow the same rule. Commands that mutate queue order should carry the expected queue revision and return a structured conflict if another controller changed it first.

Define Rust request/response structs as the contract source and generate TypeScript declarations, for example with `ts-rs`. Add runtime parsing and Rust validation separately; generated TypeScript declarations do not validate JSON. Check serializer naming, enum tagging, optional/null semantics and numeric representation with cross-language fixtures. [ts-rs documentation](https://docs.rs/ts-rs/latest/ts_rs/).

The command surface should express intent: `import_selection`, `get_library_page`, `get_playback_snapshot`, `play_entry`, `pause`, `resume`, `stop`, `seek`, `set_volume`, `set_dsp`, `set_output_device`, `replace_queue` and `mutate_queue`. Ordinary playback commands should accept opaque library/queue IDs, not arbitrary filesystem paths. Return command IDs and structured errors such as `file_missing`, `unsupported_format`, `device_unavailable`, `invalid_argument`, `revision_conflict`, `permission_denied` and `storage_unavailable`.

**5. Specify playback behavior before implementing it.**

Use explicit states: idle, loading, playing, paused, seeking, stopped, device unavailable and failed. Add buffering when network sources are implemented. Preserve user intent across loading and seek: a paused seek remains paused; a pause arriving while a file loads prevents an eventual surprise start.

| Action or event | Required behavior |
|---|---|
| Play Now from search or library | Select that track through an explicit command. Add one queue entry if needed; do not duplicate the library record. |
| Play an already selected entry | Resume if paused; restart if ended. Provide a separate Restart action when already playing. |
| Seek | Validate finite input and bounds, cancel obsolete decode work, flush obsolete frames, reset DSP state as required and acknowledge the resulting position. |
| End of file | Advance once after that entry's final output frames are consumed; React does not infer EOF from a timer. |
| Remove the active queue entry | Select the next valid entry and preserve paused/playing intent; stop if no entry remains. |
| Remove a library record | Confirm its removal from referenced queues/playlists as appropriate; never delete the user's audio file implicitly. |
| Clear queue | Stop playback and clear it. Offer Clear upcoming as a separate action that preserves the active entry. |
| Repeat off / all / one | Off stops at queue end; all wraps; one repeats the active entry at EOF. Manual Next still navigates. |
| Shuffle | Use a permutation/history model, avoid repeats until the eligible cycle is exhausted and make Previous follow playback history. |
| Previous | Restart the current entry if sufficiently far in, for example over three seconds; otherwise use history/previous entry. |
| Missing/corrupt entry | Display the reason; automatic advance may skip a bounded number of entries, stopping when none is playable. Explicit Play Now reports its own failure. |
| Device loss | Pause and explain the failure. Do not silently route private listening to laptop speakers. |
| Restart application | Restore the library, queue and position into a paused state; require an intentional play action. |

Keep `TrackId` and `QueueEntryId` separate. A library has one identity per imported file identity; a queue may intentionally contain the same track more than once. Distinguish playlist item IDs as well, so duplicate entries can be reordered and removed unambiguously.

Use integer milliseconds or another documented, JSON-safe unit at IPC boundaries; retain sample/frame counters internally where precision matters. Distinguish the frame position submitted to the device from estimated audible position and disclose unavailable latency information rather than inventing precision. Send normal progress events around 5-10 Hz and immediate state-change events. UI animation can interpolate without becoming the playback clock.

**6. Choose the audio implementation using a bounded experiment.**

B04 should take two to three engineer-days after a native build exists. The recommended first candidate is a supported Rodio version behind a small backend adapter, with an explicitly verified floating-point decoder path. The old 0.19 Symphonia adapter demonstrably uses a 16-bit intermediate; upgrading is an investigation, not proof that every precision, seek and output issue disappears. [Pinned Rodio decoder source](https://raw.githubusercontent.com/RustAudio/rodio/v0.19.0/src/decoder/symphonia.rs).

The experiment must play representative WAV/FLAC/MP3 files, preserve 24-bit reference samples before DSP, seek repeatedly while paused/playing, expose format/device data, handle shutdown and demonstrate a usable next-source boundary. Inspect whether decoding, file I/O, locking or allocation occurs in the application's output path. Feed prepared frames from bounded decoder workers when required. Record tested versions and the limitations of the chosen abstraction.

If that candidate cannot meet the release requirements cleanly, choose direct Symphonia decoding plus CPAL output with a preallocated frame buffer and a dedicated control/decoder design. Re-estimate the audio work before proceeding. Maintain one selected engine; do not carry both as production fallback implementations merely to avoid the decision. The base backlog estimates assume the adapter approach is viable; a direct output rewrite is an explicit additional scope risk.

In application code on the audio callback path, prohibit disk/network access, database work, logging, blocking locks and per-sample allocation. Use preallocated, channel-aligned buffers. Measure underruns and callback duration with low-overhead counters. FFT data is disposable telemetry: drop an entire frame/block when needed rather than losing individual interleaved samples and corrupting channel alignment.

Represent source format, processing format and negotiated output format separately. A 24-bit FLAC source does not prove 24-bit device output. Floating-point processing can preserve 24-bit PCM values before modification; it does not establish universal bit-perfect delivery or preservation of every 32-bit integer value. In shared output mode, report what the application knows about conversion and mixing.

Call the existing purist control DSP bypass until an end-to-end claim is verified. A future bit-perfect indicator needs verified source precision, unity gain, no modifying DSP/crossfade/ReplayGain, no resampling and a validated output mode. Show the reason it is unavailable. Exclusive-mode and ASIO work need a separate backend/device test matrix; current dependencies do not establish those capabilities.

Validate volume in [0,1], EQ band index in [0,9], finite gains within the supported UI range, and finite seek/rate/crossfade inputs. Start with the existing ten-band EQ and documented gain limits, smoothing coefficient/volume changes to avoid abrupt discontinuities. Evaluate EQ response at each supported sample rate; a fixed 16 kHz band needs handling when Nyquist is lower. Apply deliberate headroom and report clipping. Do not label hard clamping a soft limiter.

Playback speed is optional for the first release. If retained, implement it in one place and state whether it changes pitch. Disable or omit precision/buffer/crossfade controls until the backend actually supports and confirms them. Gapless preparation and crossfade mixing are different features and must have separate behavior and evidence.

**7. Build a durable library and a safe migration path.**

Use SQLite behind a Rust storage service, with one coordinated writer and queries on background workers. Start with a small binding such as a verified, pinned `rusqlite` version; do not expose unrestricted SQL to the WebView. Enable foreign keys, use WAL with an explicit durability/checkpoint policy, bound busy waits, parameterize queries and run migrations transactionally. An acknowledged durable user edit should survive the crash model documented by the application.

| Entity | Essential data and invariants |
|---|---|
| `media_files` | ID, native path representation, filesystem identity when available, size/mtime, authorization root, availability and last probe result. |
| `tracks` | Stable ID, file reference, title/artist/album, duration, codec, source rate/bit depth/channels, artwork reference and favorite state. Unknown fields remain unknown. |
| `artwork` | Content/cache ID, dimensions, MIME, cache-relative location and size. Never a persistent blob URL. |
| `playlists` / `playlist_items` | Playlist metadata and independently identified ordered items referencing tracks. Support reorder and deliberate duplicates. |
| `queue_items` / `playback_session` | Queue-entry IDs, order, active entry, revision, repeat/shuffle seed/history and last confirmed position. |
| `settings` | Versioned non-secret preferences, validated by the owning service. |
| `library_roots` / `scan_jobs` | Authorized roots, scan status, cancellation and reconciliation checkpoints; watcher details arrive with A01. |
| `listen_sessions` / aggregates | Accumulated actual listening time and idempotent session identity; advanced reporting arrives with A04. |
| `schema_migrations` | Applied version, timestamp and migration checksum. |

Index file identity/path lookups, playlist order, common sort/filter fields and favorite/recent queries. Add full-text search where justified by the query requirements. Page results and return only the fields needed by each screen; a 100,000-track library must not be sent as one JSON event or rendered as one DOM list. Profile the actual query plans before adding speculative indexes.

Migration from localStorage should be a versioned, bounded import. Validate old JSON, reconcile duplicate IDs/files, preserve favorites and recoverable metadata, and import into a transaction. Preserve a non-secret legacy snapshot until migration verification and a subsequent successful restart. Do not include API keys in that snapshot. Mark completion only after validation; rerunning a partially interrupted migration must be safe.

Some current entries have empty paths and cannot be made playable automatically. Retain recoverable metadata and offer folder/file relinking. Regenerate artwork from the original file; expired blob URLs are not usable backups. Restore queue and position paused. Report corrupt legacy records individually rather than discarding the entire library.

Implement a coherent database backup and a manifest containing schema/application versions and artwork handling. Use SQLite's backup facilities for a consistent snapshot; copying just the live database file while WAL writes are active is not a sound backup design. Restore into a temporary location, validate it, and switch only after success. User audio files remain external and are not implicitly copied into a library export. [SQLite backup documentation](https://www.sqlite.org/backup.html).

**8. Replace import and device handling with native workflows.**

Open files/folders through Tauri's native dialog and receive native drag/drop events. Prefer a native selection-to-import flow that can register the actual selected files before issuing opaque IDs to the UI. Do not treat a path string received through generic IPC as proof of user authorization. Tauri's desktop dialog supplies native paths, which addresses the browser `File.path` failure directly. [Native dialog documentation](https://v2.tauri.app/plugin/dialog/).

Canonicalize and validate selected paths, account for Windows reparse points and directory boundaries, and avoid string-prefix authorization checks. Do not blindly lowercase paths in ways that break case-sensitive directories. Use file identity where available and path/size/mtime reconciliation otherwise; use content hashes only when a particular deduplication or integrity requirement justifies their cost. Revalidate access when opening the file, not only during the initial scan.

Scan metadata and embedded artwork in bounded workers, for example two to four initially. Bound artwork dimensions/bytes and tag/string sizes, handle unreadable/corrupt/truncated media, and support cancellation between units of work. Prevent directory cycles and report inaccessible subdirectories. Commit batches and emit progress summaries rather than one heavyweight UI event per metadata field. Playing an already imported track should not wait for a complete folder scan.

For A01, extend this service with a debounced watcher. Coalesce change bursts, wait for partially written files to stabilize, reconcile deletes/renames, and perform a full consistency scan after watcher overflow or downtime. An unbounded filesystem event queue is unacceptable. Deduplication and persistence remain the importer's responsibility.

For output devices, return an opaque device ID, display name, default flag and actual capability information. Device names may collide or change. If the backend cannot supply a persistent unique ID, scope IDs to an enumeration generation and resolve a saved preference carefully on restart. Never silently equate a matching label with a guaranteed identical device.

Switching should preserve the active entry and intended play/pause state, open and validate the requested output, then acknowledge the applied configuration. On failure, retain a usable previous output where possible or pause with a recoverable error. Starting with no audio device must still allow the library/settings UI to open. Test USB DAC removal, Bluetooth profile changes, default-device changes and sleep/resume independently.

**9. Complete every visible user journey and control.**

Keep the current visual identity and introduce consistent spacing, typography, focus and status components while fixing the actual flows. The empty library should offer Add files and Add folder, explain supported formats and show import progress. Search should operate on the local library first; clicking a result plays that result without manufacturing another track record.

Make named playlists real entities with create, rename, add, remove and reorder operations. Clearly distinguish Play Now, Play Next and Add to Queue. Expose pending native actions and actionable errors without blocking normal navigation. A failed native call should not leave the Play button or device selector claiming success.

Virtualize large collections while retaining usable keyboard navigation and accessible row semantics. Preserve selected track/scroll position across sorting and filtering. Load bounded artwork thumbnails and cancel stale image/theme computations. For dynamic themes, sample a small image and adjust colors to meet measured contrast requirements rather than applying arbitrary averages directly.

Audit all icon buttons for accessible names. Add visible focus, Escape handling and focus restoration for overlays, and ensure Space/arrow shortcuts do not hijack inputs, buttons or assistive interactions. Test Narrator, keyboard-only navigation, reduced motion, high contrast and common Windows scale factors. Tie any accessibility statement to the tests performed.

Provide an Audio details view with source codec/rate/bit depth, processing steps, output device/configuration and reasons a requested mode is unavailable. It should help a listener make a decision without exposing internal implementation jargon. Put diagnostic details behind a support view.

Choose and document close, minimize and tray behavior. The beta can use a normal main window without a separate mini window. All OS file-open requests, including a second application invocation, must route through the same authorized ingestion and queue command path. File association registration alone is not sufficient.

**10. Constrain native access and handle secrets deliberately.**

Apply runtime checks to every command: bounded batch sizes, valid IDs, finite numeric values, rate limits for expensive work and explicit state preconditions. Validate local metadata as untrusted input. Decode and resize artwork with resource limits; render text as text and restrict any external link schemes.

Tauri plugin permissions and custom Rust command validation are separate responsibilities. Restrict registered application commands through the applicable application manifest/permissions, allow only the required window actions and avoid unnecessary filesystem/shell capabilities. Remote content must not receive native privileges. The current `std::fs` calls do not automatically inherit the fs plugin's scope. [Tauri capability model](https://v2.tauri.app/security/capabilities/).

For the beta, exclude unused network and metadata-write handlers when their feature is absent. Remove disconnected API-key entry from the released UI. Offer an explicit way to delete legacy stored keys; any connector that remains available requires a functioning native credential adapter before release. Store persistent secrets in the OS credential store, return only configured/not-configured status to React and omit values from logs, exports and crash diagnostics. Move a legacy secret only after successful native storage, then remove its plaintext copy.

Remove obsolete build-time secret defines and `VITE_*` secret conventions. Tighten CSP to shipped assets and approved resources; bundle fonts for predictable offline behavior. All retained native HTTP requests need connection/overall deadlines, cancellation, bounded redirects/body sizes and clear error mapping. Validate every redirect against the allowed schemes/destination policy. Disable unexpected requests in an advertised offline mode.

Before stable release, generate npm/Rust dependency and license inventories, run advisory checks and record triage. Block unresolved release-critical vulnerabilities. Any exception needs affected versions, reachability analysis, a responsible owner and an expiry; a zero-count frontend production audit does not establish native application security. Publish the licenses/notices that distribution actually requires.

**11. Make signed delivery and recovery part of the product.**

Start signing-account/key ownership and release-channel setup on day one because provisioning can take calendar time outside engineering estimates. Use a Windows x64 NSIS installer as the initial packaging target. Add MSI or managed deployment only when needed and qualified. Decide per-user installation, data locations, WebView2 acquisition/offline prerequisites and uninstall data retention explicitly.

CI must run from a fresh checkout with pinned Node/Rust and locked dependencies. Required jobs should perform dependency install, type/lint/format checks, meaningful frontend tests, Rust formatting/Clippy/tests, generated-contract verification and a Windows native build. Package only after those jobs pass for the same commit. Never allow a tag-triggered release to bypass the checks in a separate workflow.

Use separate trust paths for pull-request validation and protected signing/release jobs. Pin third-party workflow actions to reviewed commit SHAs, minimize token permissions and avoid exposing signing credentials to untrusted pull requests. Retain release symbols/debug information privately before stripping distributed binaries, along with build metadata, logs and hashes.

Sign the Windows executable/installer with OS code signing. Updater signing is an additional, separate mechanism. Replace the placeholder updater public key, enable updater artifacts, and generate a manifest whose filename and contents match the actual configured endpoint and target. Verify signatures through the actual update path; Tauri requires signed update artifacts. [Tauri updater documentation](https://v2.tauri.app/plugin/updater/).

Use explicit beta and stable feeds. A GitHub latest-release URL should not accidentally couple their policies. A static feed is sufficient initially; percentage-based rollout requires a deliberate cohort mechanism, while a separate beta feed supports a simple initial test cohort. Bind manifests to immutable versioned artifacts and record hashes. Promote the exact qualified artifact; do not silently rebuild different release bits after qualification.

The update flow should show release notes and progress, allow the user to defer restarting during listening, and recover from a cancelled/failed download. Verify signatures before installation. Snapshot the library before a schema-changing first run, then migrate transactionally. If migration fails, keep the previous snapshot and offer recovery instead of repeatedly opening and modifying broken data.

Test upgrade from an installed previous version, invalid signature, truncated download, offline operation, interruption at each stage and failed data migration. Do not promise automatic binary downgrade across incompatible schemas. Prefer a forward fix; when a previous installer is used for recovery, restore a compatible snapshot deliberately. Keep signing-key backup/rotation and feed-pause procedures in the release runbook.

For the limited beta, signed manual installer upgrades are acceptable if automatic updating is disabled cleanly and the upgrade/data-preservation path is tested. Signed in-app updating and its recovery evidence are required for the planned public stable milestone.

**12. Measure reliability and performance against a declared machine.**

These are proposed acceptance budgets, not measured current results or contractual SLAs. Establish a reference Windows 11 laptop with at least four physical CPU cores, 16 GB RAM and SSD storage, recording the exact CPU, Windows/WebView build, audio drivers and library corpus. Record both cold and warm runs. Adjust a budget only with evidence and a documented product tradeoff.

| Measurement | Initial target | Evidence |
|---|---|---|
| Launch to usable library | p95 under 2 seconds after first-run setup; benchmark cold/warm separately | At least 30 timed launches with a populated library |
| Play command to local audio | Warm p95 under 250 ms; cold p95 under 750 ms on reference fixtures | Native timing plus loopback/capture correlation where available |
| Seek completion | p95 under 500 ms for declared seekable formats | Near-start/middle/end and paused/playing corpus |
| Local search with 100k tracks | p95 under 150 ms for the first result page | Indexed query and frontend render timings |
| CPU, all app processes | Idle under 1%; audio-only under 3%; visible spectrum under 8% on the reference machine | Process-tree measurements with documented normalization |
| Memory, all app processes | Target under 400 MB steady state; bounded artwork/decoder caches | Working-set/private-byte reports including WebView subprocesses |
| Event traffic | Progress around 5-10 Hz; spectrum at most 20-30 Hz while visible | Event counters and hidden/minimized-window check |
| Playback stability | Eight-hour beta and 24-hour stable soaks without unexplained underruns, stuck playback or crashes | Native counters, logs, frame/capture evidence and device matrix |
| Memory stability | No monotonic growth; under 10% growth after warm-up on a repeated fixed workload | Comparable steady-state windows, with caching effects identified |
| User-data durability | No lost acknowledged library/playlist edits in the defined crash tests | Kill/restart and storage-failure tests |

Keep callback instrumentation lightweight and outside the signal path where possible. Compare processing duration to the actual configured device period and investigate outliers. Do not claim real-time guarantees from a frontend CPU graph. Publish measured figures only after this qualification; beta documentation can state known limits.

**13. Validate complete behaviors at the right layer.**

Use unit tests for pure queue/DSP/validation logic, Rust integration tests for decode/storage/lifecycle boundaries, React tests for user interactions and desktop tests for the real Tauri bridge. Mocked browser tests remain useful but cannot prove installed window permissions, audio-device behavior or native seek.

| Layer | Required coverage |
|---|---|
| Contracts | Rust-serialized device/state/error fixtures parsed by React; generated declarations checked for drift; malformed input rejected. |
| Queue/state machine | EOF, repeated/duplicate entries, play-selected, clear/remove, shuffle history, repeat modes and concurrent commands. Include generated command sequences with invariant checks. |
| Audio correctness | Reference 16/24-bit samples, mono/stereo handling, seek accuracy, EOF once, DSP bypass, EQ response, clipping behavior and stale-buffer cancellation. |
| Library/storage | Deduplication, Unicode/long paths, missing files, migration from real legacy fixtures, transaction failure, storage full/read-only, backup and restore. |
| Frontend | The eight audit behaviors, loading/error states, correct device options, native rate metadata and keyboard interaction. |
| Installed desktop | Import/play/seek/next/restart, window actions, file associations, second-instance opening and real command/event transport. |
| Hardware/manual | Built-in audio, USB DAC and Bluetooth; unplug/replug, sleep/resume, no-device startup, rapid switching and default-device changes. |
| Release/update | Clean install/uninstall, previous-version update, signature rejection, interruption, failed migration and recovery. |
| Accessibility | Narrator, keyboard-only core flows, focus, contrast, reduced motion and tested display scale factors. |

Use generated or redistributable media fixtures with recorded format properties and expected samples; keep a small mandatory CI corpus and a broader release corpus. Include truncated/corrupt files, oversized metadata/artwork, very short/long files and mismatched extensions. File duration reported by tags is not proof of the decoded frame count.

For gapless tests, first join known same-rate PCM fixtures and verify no introduced/dropped samples at the seam. Then validate decoder delay/padding handling for each advertised compressed format. With differing source rates, specify whether the player resamples to a fixed device rate or reconfigures output; native-rate renegotiation may prevent an uninterrupted transition. A screen recording of the progress bar is insufficient audio evidence.

Use WebdriverIO with the Tauri service for desktop journeys. On Windows, a native `tauri-driver` route can exercise the app; an embedded test server is another supported route. If embedded test instrumentation is used, gate it behind a test-only feature and assert that release artifacts exclude it. Current Tauri documentation describes support on Windows, Linux and macOS through the service; test approach and native-driver support differ by platform. [Tauri WebDriver guidance](https://v2.tauri.app/develop/tests/webdriver/).

For every pull request, run the checks relevant to its change and the required baseline checks. Put expensive library/device/soak matrices in scheduled or release qualification jobs. Do not compensate for missing native evidence with a blanket frontend coverage percentage. Save logs and machine/fixture versions so results are reproducible.

**14. Build advanced features in dependency order.**

The next priorities after stable should be watched folders, ReplayGain and the native mini player/media controls: these extend the core listening experience. The companion backlog contains effort ranges and specific acceptance criteria for all ten follow-on packages.

| Package | Implementation and product value | Required boundary |
|---|---|---|
| A01: watched folders | Reuse the importer, persist roots, coalesce changes and recover missed events through reconciliation. | Must converge after event loss without duplicating library records or blocking playback. |
| A02: metadata editing | Use field-level patch semantics: absent means unchanged; explicit clear removes a field. Preserve other tags/artwork. Stage and verify writes, keep recoverable originals and detect concurrent edits. | Avoid direct destructive rewrites, especially while a file is open. Validate the replacement strategy and metadata/file attributes on Windows. |
| A03: ReplayGain/loudness | Read track/album gain and peak metadata; add mode selection, preamp and clipping policy. Scan missing analysis in background jobs when enabled. | Distinguish measured peak/true-peak behavior; do not claim protection that has not been tested. |
| A04: smart playlists/history | Store actual listening sessions, batch writes, define thresholds and generate playlists from indexed rules. | Seeking, pause and buffering do not count as listening; retry/crash recovery cannot double-count a session. |
| A05: crossfade | Decode two sources, schedule overlap, mix a documented curve with headroom and handle seek/skip cancellation. | Define precedence with album-gapless, repeat-one, ReplayGain and DSP bypass; expose one consistent setting. |
| A06: direct radio | Add a distinct HTTP source, bounded buffering, timeouts, cancellation, redirect validation, reconnect and stream metadata. | Do not pass URLs to local file decoding or represent radio as YouTube. Test unsupported live formats and non-seekable state. |
| A07: mini player/media controls | Create a separate native window with minimal permissions and wire Windows media controls to the same playback controller. | All windows and OS controls must share state, queue identity and command ordering. |
| A08: lyrics/themes | Cache and cancel requests; distinguish plain from synchronized lyrics; bound artwork processing and enforce contrast. | Never show a previous track's delayed response as the current track's data; keep privacy behavior explicit. |
| A09: macOS | Select OS/architecture support, qualify audio and file behavior, implement platform integrations, sign/notarize and test updates. | Pass the same core acceptance gates on actual hardware; a cross-platform build alone is insufficient. |
| A10: Linux | Start with a small declared distribution/audio-server/package matrix; validate WebKit dependencies, desktop integration and device permissions. | Publish only the combinations actually tested; distribution-specific behavior needs its own support scope. |

Prefer an explicit source model such as local library item versus direct stream. A future provider-backed source needs its own resolver, authentication, playback restrictions and error contract. YouTube watch pages cannot be treated as local audio files; a supported embed or other permitted playback integration requires a separate design. Spotify/Apple metadata import must use real results and disclose unresolved tracks. Do not ship fabricated fallbacks as successful integration.

AI DJ should first mean explainable queue suggestions from real library metadata, with user review and no blocking dependency in playback. If an external model is used, disclose what metadata leaves the machine, store credentials natively, impose request budgets and make ordinary playback work without the service. Beatmatching or seamless generated transitions would be separate audio research.

VST hosting needs a dedicated design for plugin discovery, separate-process crash containment, timeouts, latency compensation, version/architecture compatibility and recovery. A plugin must not be allowed to take down the main player through an unexamined in-process host. Do not estimate completion from the existing stub.

Spatial audio and room correction require explicit channel layouts, calibration/measurement inputs, filter stability, latency and loudness safety evaluation. A module that returns unchanged samples is not a shipped feature. Treat these, verified exclusive/bit-perfect output, DSD and synchronization as research milestones with a small prototype, evidence and a go/no-go decision before a delivery estimate.

For organizational customers, add managed settings, signed MSI deployment, update deferral, offline license behavior and a support policy when required. Accounts, SSO/RBAC and cloud sync belong to an actual organization/cloud product specification. If sync is introduced, start with playlist/settings metadata, conflict/deletion rules and a clear privacy/key-recovery model before attempting media-file synchronization. These projects are outside the Windows launch estimate.

**15. Deliver through explicit milestones and gates.**

| Milestone | Required work | Exit evidence | Base effort |
|---|---|---|---:|
| Build/native proof | B01-B05; storage work can begin once contracts settle | Clean install/build, first real native playback, audio-backend decision and contract fixtures | Included below |
| Private Windows beta | B01-B17 | All eight audit behaviors resolved; core installed journeys pass; signed installer; durable migration; device recovery; eight-hour soak; honest capability list | 27-49 engineer-days |
| Public Windows stable | S01-S08 after beta | Verified gapless scope, performance/large-library qualification, signed update/recovery, accessibility and privacy checks, 24-hour soak, support runbook | 13-27 additional engineer-days |
| Advanced features | A01-A08 after stable | Each feature passes its own end-to-end and failure tests before exposure | 21-38 additional engineer-days |
| macOS, then Linux | A09-A10 | Platform-specific signed/distributable artifacts and the same core quality evidence | 10-20 additional engineer-days |

The Windows beta and stable base total is **40-76 engineer-days**. These ranges include normal implementation, review and focused verification. Add 20-30% scheduling contingency for integration and discovered defects. They exclude external signing-provider delays, a rejected audio adapter requiring a direct CPAL redesign, research projects and enterprise fleet/cloud features. The advanced/platform ranges are preliminary and should be re-estimated against the stable codebase.

For one experienced engineer, the base beta effort is roughly six to ten working weeks, with three to six further weeks for stable. With one experienced Rust/audio engineer, one React/Tauri engineer and part-time QA/release support, a reasonable planning window is approximately four to seven calendar weeks for beta and two to four more for stable, before contingency and external delays. Dependencies and native-specialist capacity limit parallelism. Set an actual launch date after the native proof and first integrated playback journey pass.

The critical integration order is baseline/toolchain -> audio proof and contracts -> native controller plus library/import -> queue/seek/device/migration -> installed journeys -> qualified beta -> update/recovery/performance -> stable qualification. Signing setup, fixture creation, accessibility review and documentation can proceed alongside implementation. PRs must remain small enough to review; the 35 packages are not a requirement to produce exactly 35 giant commits.

Use three responsible roles even if one person fills several: a native/audio owner for engine/data correctness, a frontend owner for contracts/UX, and a release/QA owner for qualification and signing. The release owner maintains one evidence checklist against the exact candidate hash. Release evidence must state what was tested, on which platform/device, with which result and who accepted it.

Block a candidate for any known crash on a supported core path, data loss, wrong-track playback, stuck playback/queue transition, unsafe command input, invalid signatures or unusable update/recovery. A feature may leave the release scope if it can be completely gated and documented; weakening those core gates is not a schedule tool. Cosmetic findings can be prioritized separately with clear ownership.

**16. Start with an actionable first implementation batch.**

During the first implementation day, preserve and inventory the working tree, turn the eight audit failures into tracked requirements, repair the dependency tuple and get a reproducible Windows toolchain. Start code-signing provisioning and collect a small redistributable audio corpus plus access to a USB DAC and Bluetooth device. Record the existing release history and data formats before choosing versions or writing migrations.

During the next working day, compile/launch the real app, run the smallest native file -> decode -> output -> pause -> seek journey, and begin B04's precision/lifecycle experiment. In parallel where staffing permits, define the device and playback DTOs and draw the schema/migration boundary. The deliverable is a recorded native result and the first contract tests; if environment setup slips, record the blocker and revise the schedule rather than claiming the proof passed.

After that proof, implement one complete vertical slice: native picker -> authorized media record -> library row -> Play Now -> confirmed playback snapshot -> pause/seek -> EOF -> restored paused session. Use it to validate architecture before filling out every page. Integrate queue semantics and device handling next, then finish scale, release and advanced work in the backlog order.

Keep architecture decisions short and concrete: one page each for playback ownership, decoder/output choice, persistence/migration, source model and release trust. Each decision should identify the tested alternatives, selected behavior, limitations and conditions for revisiting it. Keep README/changelog claims synchronized with the capability manifest during each merge.

**17. Resolve the remaining risks through evidence.**

| Risk or assumption | Early action | Decision owner / release effect |
|---|---|---|
| Native engine has never been built in this audit environment | B03/B04 build and hardware experiment | Native owner; determines audio estimate and architecture |
| Upgraded Rodio may not meet precision, seek or output requirements | Prove the required path before broad refactoring | Native owner; direct CPAL fallback triggers re-estimation |
| Existing users/releases and real localStorage datasets are unknown | Inventory distribution history; collect sanitized migration fixtures | Lead/data owner; determines versioning and migration support |
| Windows minimum and hardware support are not yet formalized | Qualify an initial Windows 11 x64 matrix and publish it | Release owner; controls advertised compatibility |
| Signing identity/provider availability is unknown | Start provisioning and backup ownership on day one | Release owner; may affect calendar launch date |
| Library scale/performance targets are provisional | Establish a reproducible 10k/100k corpus and baseline | Native/frontend owners; informs query/UI optimization |
| Product meaning of enterprise may expand into fleet/cloud requirements | Keep initial scope to desktop reliability/support; separately specify deployment/accounts if required | Product owner; adds explicitly estimated scope |
| Cross-platform audio/packaging differs from Windows | Reuse contracts/tests, then validate each OS on actual hardware | Platform owner; macOS/Linux ship after their gates |

The implementation should begin with **B01-B05**, then the native import/playback/library slice. Feature expansion becomes efficient once the state, audio and storage contracts are dependable; every later control and window can then share the same tested behavior.
