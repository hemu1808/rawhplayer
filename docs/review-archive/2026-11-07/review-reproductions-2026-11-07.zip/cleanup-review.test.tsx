import React from 'react';
import { act, cleanup, renderHook } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { LibraryProvider, useLibrary } from '../context/LibraryContext';
import { emptyLibrary, parseLibrarySnapshot } from '../services/libraryStore';

const harness = vi.hoisted(() => ({
  invoke: vi.fn(),
  handlers: new Map<string, (event: { payload: unknown }) => void>(),
  player: {
    reportError: vi.fn(), setLoading: vi.fn(), registerResumeHandler: vi.fn(),
    refreshAudioInfo: vi.fn().mockResolvedValue(undefined),
  },
}));
vi.mock('@tauri-apps/api/core', () => ({ invoke: harness.invoke, convertFileSrc: (path: string) => path }));
vi.mock('@tauri-apps/api/event', () => ({
  listen: vi.fn(async (name: string, handler: (event: { payload: unknown }) => void) => {
    harness.handlers.set(name, handler);
    return () => harness.handlers.delete(name);
  }),
}));
vi.mock('../context/PlayerContext', () => ({
  usePlayer: () => harness.player,
  errorMessage: (error: unknown) => String(error),
}));

afterEach(() => {
  cleanup();
  vi.useRealTimers();
  delete window.__TAURI_INTERNALS__;
  harness.handlers.clear();
});

describe('2026-11-07 review reproductions (observed behavior)', () => {
  it('rejects a 100001-track snapshot below the native 250000-track limit', () => {
    const snapshot = emptyLibrary();
    snapshot.tracks = Array.from({ length: 100_001 }, (_, index) => ({
      id: String(index), name: 'Track', artist: 'Artist', path: `C:/music/${index}.wav`,
    }));
    expect(() => parseLibrarySnapshot(snapshot)).toThrow('Invalid library backup.');
  });

  it('defers favorite persistence indefinitely while paused playback events arrive every 100 ms', async () => {
    vi.useFakeTimers();
    window.__TAURI_INTERNALS__ = {} as typeof window.__TAURI_INTERNALS__;
    const snapshot = emptyLibrary();
    snapshot.tracks = [{ id: 'one', name: 'Track', artist: 'Artist', path: 'C:/music/one.wav' }];
    snapshot.queue = [{ id: 'q1', trackId: 'one' }];
    snapshot.session.currentQueueId = 'q1';
    harness.invoke.mockImplementation(async (command: string) => command === 'library_load' ? snapshot : undefined);
    const wrapper = ({ children }: { children: React.ReactNode }) => <LibraryProvider>{children}</LibraryProvider>;
    const { result } = renderHook(() => useLibrary(), { wrapper });
    await act(async () => {});
    expect(result.current.ready).toBe(true);
    await act(async () => result.current.playQueueEntry('q1'));
    await act(async () => vi.advanceTimersByTimeAsync(500));
    harness.invoke.mockClear();
    act(() => result.current.toggleLike('one'));
    expect(result.current.snapshot.tracks[0].isLiked).toBe(true);
    const emit = harness.handlers.get('playback_update');
    expect(emit).toBeTypeOf('function');
    for (let index = 0; index < 20; index++) {
      act(() => emit!({ payload: { queue_id: 'q1', current_time: 0, is_playing: false } }));
      await act(async () => vi.advanceTimersByTimeAsync(100));
    }
    expect(harness.invoke.mock.calls.filter(([command]) => command === 'library_save')).toHaveLength(0);
    await act(async () => vi.advanceTimersByTimeAsync(450));
    expect(harness.invoke.mock.calls.filter(([command]) => command === 'library_save')).toHaveLength(1);
  });
});
