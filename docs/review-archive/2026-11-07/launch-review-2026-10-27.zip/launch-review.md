# RawhPlayer launch review — 2026-10-27

Reviewed `D:/repos/rawhplayer`, commit `1617b9c`, package version `3.0.0`. The working tree was clean. This is a proposal and evidence report; application source was not changed. The existing `codex.md` also records a proposal-only project preference.

**Recommendation: launch a focused local music player after repairing the core journeys.** React 19, TypeScript, Tauri 2, native decoding, an implemented equalizer, FFT visualization, lazy pages and initial accessibility work give the project a useful foundation. A framework rewrite would not solve the current problems. The immediate work is connecting the UI and native engine correctly, preserving users' libraries, and producing a dependable installed application.

The proposed product promise is: **your local music, dependable playback, and a clear view of what reaches your audio device.** Start with Windows as a proposed launch scope, then extend the supported platform matrix when native validation is available. This scope is a recommendation, not an established user requirement.

**What was actually verified**

| Check | Result | Limit |
|---|---|---|
| `node node_modules/typescript/bin/tsc --noEmit` | Passed | Compile-time checks do not validate native payloads. |
| `node node_modules/vitest/vitest.mjs run --maxWorkers=1 --no-file-parallelism --no-cache --configLoader runner` | 3 files, 30 tests passed | Native commands/listeners are mocked. Tests primarily cover state, persistence and constants. |
| `npm run build` | Passed; main JS 334.11 kB, 99.00 kB gzip | Run in an exported copy of the reviewed commit using existing installed dependencies. Not a fresh-install or native build proof. |
| `npm run lint` | Failed: ESLint executable missing | Dependencies also omit required lint plugins, Prettier and coverage provider. |
| `npm audit --omit=dev --json` | 0 reported npm production vulnerabilities | Does not cover Rust, application logic or all supply-chain risks. |
| `npm audit --json` | 9 affected packages: 4 high, 5 moderate | Findings are in development dependencies. Review exposure and update compatible toolchain versions; this is not evidence of nine exploitable installed-app flaws. |
| Native compile, installer, audio devices | Not run | `cargo` and `rustc` unavailable on PATH; no hardware playback or installed-app test was performed. |

The development audit names Vite, Vitest, @vitest/mocker, browserslist, esbuild, baseline-browser-mapping, postcss-selector-parser, source-map-js and undici. A follow-up registry request failed; a permitted retry succeeded. Vitest also emitted React-plugin/esbuild deprecation warnings. Align the build/test toolchain deliberately rather than applying a forced major upgrade without validation.

**Fix these before a public release**

| Priority | Finding | Evidence | Required outcome |
|---|---|---|---|
| P0 | Local import does not reliably provide a native absolute path. | [LibraryContext.tsx:192](D:/repos/rawhplayer/context/LibraryContext.tsx:192) expects `File.path` or `webkitRelativePath`; [FilesPage.tsx:126](D:/repos/rawhplayer/pages/FilesPage.tsx:126) uses browser file input. | Native file/folder picker and path-based drag/drop; import and play a real file from a clean install. |
| P0 | Selecting a search result appends it and plays library index zero. | [App.tsx:127](D:/repos/rawhplayer/App.tsx:127). | Select by stable track ID; local search must not duplicate the track or play another item. |
| P0 | Seeking is unsupported through the audio wrapper. | [audio_engine.rs:149](D:/repos/rawhplayer/src-tauri/src/audio_engine.rs:149) implements `Source` without forwarding `try_seek`; call site at line 643. | Forward supported seeks and reset dependent DSP/visualizer state; verify against real codec fixtures. |
| P0 | Device settings use the wrong IPC payload shape. | [SettingsPage.tsx:35](D:/repos/rawhplayer/pages/SettingsPage.tsx:35) accepts the array as strings and renders objects at line 189; [audio_engine.rs:402](D:/repos/rawhplayer/src-tauri/src/audio_engine.rs:402) returns `{name,is_default}` objects. | Typed device contract, safe rendering, device-unavailable state and an error boundary. |
| P0 | Track completion is disconnected from queue progression. | [App.tsx:82](D:/repos/rawhplayer/App.tsx:82) requires `isPlaying`; [audio_engine.rs:365](D:/repos/rawhplayer/src-tauri/src/audio_engine.rs:365) sets it false on an empty sink and emits `track_ended` at line 378, with no frontend subscriber. | Explicit track-end/transition events carrying track and queue IDs; test automatic next, repeat and shuffle. |
| P0 | Radio and online search cannot play through the current local-file engine. | [audio_engine.rs:495](D:/repos/rawhplayer/src-tauri/src/audio_engine.rs:495) rejects non-files; radio and YouTube provide HTTP/watch URLs. | Hide unfinished online playback from launch or implement a separate validated streaming path with appropriate provider integration. |
| P0 | Unchecked IPC values can terminate the process. | [audio_engine.rs:637](D:/repos/rawhplayer/src-tauri/src/audio_engine.rs:637) permits negative seek into `Duration::from_secs_f64`; line 661 directly indexes EQ bands. Release profile uses `panic = "abort"`. | Validate finite values, ranges and indices at the Rust boundary and return structured errors. |
| P0 | Update delivery is incomplete. | [tauri.conf.json:95](D:/repos/rawhplayer/src-tauri/tauri.conf.json:95) contains a placeholder public key; no update UI, matching manifest generation or updater-artifact configuration found. | Complete and test signed updates, or deliberately ship an accurately documented manual update process for the first limited beta. |
| P0 | Release workflow can build a tag without the separate test workflow being a prerequisite. | [release.yml:13](D:/repos/rawhplayer/.github/workflows/release.yml:13). | Validate the exact release commit; sign and promote the validated artifact. Draft release creation is already configured. |

The seek conclusion is a source-level inference confirmed against the pinned [Rodio 0.19 implementation](https://raw.githubusercontent.com/RustAudio/rodio/v0.19.0/src/source/mod.rs): its default `try_seek` returns `NotSupported`. Native execution remains outstanding. Tauri's [dialog documentation](https://v2.tauri.app/plugin/dialog/) confirms its desktop picker returns filesystem paths.

Additional reliability work is necessary: removing the current queue item can change the displayed track without changing audible playback, because playback is keyed only to array index; clearing the list does not stop the sink. Artwork object URLs are serialized and become invalid across launches. Saved state lacks schema/version validation. Errors mostly go to the console, leaving the user without recovery actions.

**Treat the current feature inventory honestly**

| Capability | Current implementation | Launch treatment |
|---|---|---|
| Native local decoder, equalizer, FFT display | Substantial implementation exists | Keep; verify actual audio behavior and numerical correctness. |
| Dynamic artwork theme | Exists; averages full-size images and changes one color token | Improve caching, contrast and stale-request handling. |
| Output device selection | Lists devices; selection changes React state only | Complete it or disable the control with clear status. |
| Crossfade | Rust stores a duration and has a TODO | Do not present as functioning. |
| Gapless queue, folder watcher, metadata commands, media keys | Backend pieces exist but lack frontend integration | Complete through an explicit playback/library contract. |
| Buffer, precision and speed controls | Several only affect frontend state | Bind to supported engine capabilities or remove the controls. |
| API-key settings | Saved in localStorage; native services read environment variables | Use native credential storage and a working connection check. |
| Spotify/Apple playlist bridge | Labeled simulated demo; fixed song metadata; parent does not provide the import callback | Remove from the production navigation until a real integration is built. |
| YouTube search fallback | Produces fabricated results after errors | Show an honest configuration/network error. Never silently substitute demo content. |
| AI DJ, room correction, spatial audio, VST hosting | Placeholder modules; pass-through/empty/error behavior | Keep out of launch commitments. |
| Bit-perfect/lossless badges | UI state or fallback labels, not verified end-to-end output | Replace with measured signal-path facts and an explicit DSP-bypass label. |

**Modern code quality: the architectural changes with the highest return**

1. Separate the library, playlists, queue and playback session. The library owns tracks; playlists reference tracks; queue entries have their own IDs and can repeat a track; the native session owns the audible item and position. Clearing a queue must not clear the music library.
2. Establish one typed IPC layer. Generate or maintain matching Rust/TypeScript payloads and validate persisted/untrusted data at runtime. Use states such as loading, playing, paused, ended and failed, with clear user actions. Ignore stale completion events when the user changes tracks rapidly.
3. Split the 755-line audio module into output/device lifecycle, decoder, DSP, analysis and queue components. Give the output stream a clear owner thread; review blanket unsafe Send/Sync claims. Use bounded analysis buffers so visualization cannot disrupt playback. Prepare replacement media before stopping a healthy current track.
4. Introduce a durable SQLite library with migrations, background scans and an artwork cache. Use the existing native metadata and watcher work as a starting point. Add deletion/rename reconciliation, deduplication, cancellation and progress. Move listening-stat updates out of full localStorage serialization every second.
5. Add targeted tests for the failures above: native payload contracts, invalid IPC input, actual seek/queue fixtures, same-index replacement, clearing a queue, import/restart and missing devices. Retain useful existing tests; test count alone is not a release criterion.
6. Finish accessibility and resilience: error boundaries, visible retry actions, named icon controls, focus restoration, closed drawers removed from keyboard navigation, and no global Space interception while a control handles Space. Preserve reduced-motion support.

**Advanced features worth building, in order**

| Order | Feature | User value | Technical acceptance |
|---|---|---|---|
| 1 | Signal-path inspector | Explains exactly how the file reaches the speakers. | Display source codec/rate/depth, enabled DSP, resampling, actual output rate/device and clipping. Unknown values remain unknown. Never infer bit-perfect from an EQ toggle. |
| 2 | Gapless albums + track/album ReplayGain | Live recordings and albums flow continuously; loudness is predictable. | Preload with explicit native transition events; test boundaries with audio fixtures; manage headroom and clipping. Add optional crossfade only after this works. |
| 3 | Smart library and real playlists | Useful with thousands of albums. | Saved rules for artist/genre/rating/format/unplayed/recently added; native search index, durable artwork and missing-file repair. Distinguish playlist operations from queue operations. |
| 4 | Adaptive listening screen | A distinctive, polished player experience. | Cached artwork palettes with readable text, a precomputed seekable waveform, local synchronized LRC lyrics and calm reduced-motion behavior. |
| 5 | Native desktop experience | Feels integrated with the computer. | Functional OS media keys/session metadata, tray actions, file-open handling, a genuine compact window, remembered geometry and safe session restore. |
| 6 | Device profiles and library tools | A credible premium feature set. | Per-device EQ/volume defaults, output hotplug recovery, metadata editing with backup/undo, duplicate review and portable library/settings export. |
| 7 | Explainable local queue suggestions | Helpful discovery within the user's own collection. | Use existing listening history first; optional background BPM/key/energy analysis later. Let users inspect and override recommendations. |

Keep VST hosting, room calibration, spatial audio, cloud sync and broad streaming-provider integrations for later milestones. Each introduces a separate reliability or service dependency. If built, plugins need failure isolation, calibration needs measured correctness, and sync needs a conflict and recovery model.

**Enterprise features appropriate to a desktop player**

For launch, prioritize signed installers, release provenance/checksums, a dependency inventory/SBOM, a secure update path, recoverable library migrations, restricted native capabilities, and an exportable diagnostic bundle that redacts paths and credentials. Any uploaded crash reports should have clear consent and retention controls.

For organizational customers, add managed deployment/silent installation, update channels and maintenance policies, offline installation, administrator policy to disable external services, and portable configuration. Add organization accounts/SSO only if an actual shared cloud service or buyer need requires them.

Publisher signing and updater signatures are distinct work. Tauri's [updater documentation](https://v2.tauri.app/plugin/updater/) specifies signature verification and update artifacts; its [Windows signing documentation](https://v2.tauri.app/distribute/sign/windows/) covers publisher signing. The repository currently supplies updater signing variable names in CI, but that does not prove secrets exist or installer signing is configured.

Review [Tauri capabilities](https://v2.tauri.app/security/capabilities/) command by command. Scope file operations to explicitly selected roots where practical and validate custom Rust commands independently of frontend checks. Move API keys into OS-backed storage. Bundle fonts for offline reliability and update privacy disclosures to match lyrics lookup and other actual network requests. Add real export/delete actions.

**A concrete launch sequence**

| Milestone | Deliverable | Exit evidence |
|---|---|---|
| A — Reliable local candidate | Native import, correct selection/queue/seek, safe settings, accurate feature labels and user-facing errors. | Install → import → play → seek → next → edit queue → restart succeeds with a codec fixture library. Invalid files/commands do not crash. |
| B — Durable library and desktop polish | Separate library/queue, persistent artwork/session, watched folders, functional native controls and accessible navigation. | Restore after interruption; scan/rename/delete reconciliation; keyboard walkthrough; output disconnect/reconnect and sleep/resume. |
| C — Private beta | Signed Windows candidate, exact-commit CI gates, tested updates/recovery, diagnostics and accurate docs. | Clean-machine install/uninstall, update from previous build, failed-download/invalid-signature handling, long playback sessions and feedback triage. |
| D — Public release | Supported format/device matrix, stable download, onboarding, changelog, privacy/support workflow and selected differentiators. | No unresolved blockers in the supported scope; reproducible release and recovery; performance and accessibility evidence. |

Suggested performance targets, to validate on named reference hardware: search over 10,000 tracks under 100 ms at p95; warm launch to usable library within 2 seconds; no observed playback underruns during an eight-hour local playback test; bounded memory during import and analysis. These are proposed targets, not current measurements. Include 100,000-track stress tests before claiming very-large-library support.

The first implementation batch should repair contracts and the core playback journey, remove or disable unfinished launch controls, fix lint tooling, and add the regression tests that currently missing behavior needs. Native tooling and physical-device testing are required before setting a confident public release date.
